import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import matplotlib.pyplot as plt
from datetime import datetime
import scipy.io as sio
import math

im = np.load('E:/project/unmixing/unmixing/daan-update/samson/Y.npy')


class Denoise(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Conv3d(in_channels=1, out_channels=128, kernel_size=(3, 3, 6), stride=(1, 1, 2),
                      padding=(1, 1, 0), bias=False),
            nn.BatchNorm3d(64),
            nn.Conv3d(in_channels=128, out_channels=64, kernel_size=(3, 3, 4), stride=(1, 1, 2),
                      padding=(1, 1, 0), bias=False),
            nn.ReLU(),
            nn.MaxPool3d(2, 2),  # [, 64, 48, 48]
            nn.BatchNorm3d(64),
            nn.Conv3d(in_channels=64, out_channels=32, kernel_size=(3, 3, 5), stride=(1, 1, 2),
                      padding=(0, 0, 0), bias=False),
            nn.ReLU(),
            nn.BatchNorm3d(64),
            nn.Conv3d(in_channels=32, out_channels=16, kernel_size=(1, 1, 3), stride=(1, 1, 2),
                      padding=(0, 0, 0), bias=False),
            nn.ReLU(),
            nn.BatchNorm3d(128),
            nn.Conv3d(in_channels=16, out_channels=8, kernel_size=(1, 1, 4), stride=(1, 1, 2),
                      padding=(0, 0, 0), bias=False),
            nn.ReLU(),
            nn.BatchNorm3d(128),
            nn.Conv3d(in_channels=8, out_channels=3, kernel_size=(1, 1, 3), stride=(1, 1, 1),
                      padding=(0, 0, 0), bias=False),
            nn.ReLU(),
            nn.MaxPool3d(2, 2),
            nn.BatchNorm3d(256)
        )
        self.decoder = nn.Sequential(
            nn.ConvTranspose3d(in_channels=8, out_channels=3, kernel_size=(1, 1, 3), stride=(1, 1, 1),
                               padding=(0, 0, 0), bias=False),
            nn.ReLU(),
            nn.BatchNorm3d(128),
            nn.ConvTranspose3d(in_channels=16, out_channels=8, kernel_size=(1, 1, 4), stride=(1, 1, 2),
                               padding=(0, 0, 0), bias=False),
            nn.ReLU(),
            nn.BatchNorm3d(128),
            nn.ConvTranspose3d(in_channels=32, out_channels=16, kernel_size=(1, 1, 3), stride=(1, 1, 2),
                               padding=(0, 0, 0), bias=False),
            nn.ReLU(),
            nn.BatchNorm3d(64),
            nn.ConvTranspose3d(in_channels=64, out_channels=32, kernel_size=(3, 3, 5), stride=(1, 1, 2),
                               padding=(0, 0, 0), bias=False),
            nn.ReLU(),
            nn.BatchNorm3d(32),
            nn.ConvTranspose3d(in_channels=128, out_channels=64, kernel_size=(3, 3, 4), stride=(1, 1, 2),
                               padding=(1, 1, 0), bias=False),
            nn.ReLU(),
            nn.BatchNorm3d(16),
            nn.ConvTranspose3d(in_channels=1, out_channels=128, kernel_size=(3, 3, 6), stride=(1, 1, 2),
                               padding=(1, 1, 0), bias=False),
            nn.ReLU()
        )

    def forward(self, im):
        code = self.encoder(im)
        output = self.decoder(code)
        return code, output


class AutoEncoder(nn.Module):
    def __init__(self, L, P, device):
        super().__init__()
        self.device = device  # Set the device attribute
        self.model = Denoise().to(self.device)
        self.encoder = nn.Sequential(
            nn.Linear(L, L // 2, bias=True),
            nn.ReLU(),
            nn.Linear(L // 2, L // 4, bias=True),
            nn.ReLU(),
            nn.Linear(L // 4, P, bias=True),
            nn.Softmax(dim=1),
        )
        self.decoder = nn.Linear(P, L, bias=False)

    def forward(self, y):
        code = self.encoder(y)
        output = self.decoder(code)
        E = code
        A = F.softmax(E, dim=-1)
        Q = E
        return E, A, Q, output, code


class MLM(nn.Module):
    def __init__(self):
        super(MLM, self).__init__()
        self.fc1 = nn.Linear(9034, 128)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Linear(128, 64)
        self.relu2 = nn.ReLU()
        self.fc3 = nn.Linear(64, 32)
        self.relu3 = nn.ReLU()
        self.fc4 = nn.Linear(32, 1)

    def forward(self, L, P, Q, Z):
        L = torch.tensor(L, dtype=torch.float32) if not isinstance(L, torch.Tensor) else L
        P = torch.tensor(P, dtype=torch.float32) if not isinstance(P, torch.Tensor) else P
        Q = torch.tensor(Q, dtype=torch.float32) if not isinstance(Q, torch.Tensor) else Q
        Z = torch.tensor(Z, dtype=torch.float32) if not isinstance(Z, torch.Tensor) else Z

        X = torch.cat((L, P, Q, Z), dim=1)
        out = self.fc1(X)
        out = self.relu1(out)
        out = self.fc2(out)
        out = self.relu2(out)
        out = self.fc3(out)
        out = self.relu3(out)
        out = self.fc4(out)

        mlmloss = torch.mean(torch.square(out - torch.matmul(L, P.T)))
        return out, mlmloss


def getGaussKernel(sigma, height, width):
    # 第一步：构建高斯矩阵
    gaussMatrix = np.zeros([height, width], np.float16)
    # 得到中心点的位置
    cH = (height - 1) / 4
    cW = (width - 1) / 4
    # 计算gauss(sigma, r, c)
    for r in range(height):
        for c in range(width):
            norm2 = math.pow(r - cH, 2) + math.pow(c - cW, 2)
            gaussMatrix[r][c] = math.exp(-norm2 / (2 * math.pow(sigma, 2)))
    # 第二步：计算高斯矩阵的和
    sumGM = np.sum(gaussMatrix)
    # 第三步：归一化
    gaussKernel = gaussMatrix / sumGM
    return gaussKernel


def smooth_matrix(height, width):
    """Return smooth matrix h (numpy array)"""
    getGaussKernel = width * height
    h = np.eye(getGaussKernel)

    for i in range(getGaussKernel):
        if i - width >= 0 and i + width <= getGaussKernel - 1 and i % width != 0 and (i + 1) % width != 0:
            h[i + 1, i] = -0.25
            h[i - 1, i] = -0.25
            h[i + width, i] = -0.25
            h[i - width, i] = -0.25
        elif i - width < 0:
            if i == 0 or i == width - 1:
                h[1, 0] = -0.5
                h[width, 0] = -0.5
                h[width - 2, width - 1] = -0.5
                h[2 * width - 1, width - 1] = -0.5
            else:
                h[i - 1, i] = -1 / 3
                h[i + 1, i] = -1 / 3
                h[i + width, i] = -1 / 3
        elif i + width > getGaussKernel - 1:
            if i == getGaussKernel - 1 or i == getGaussKernel - width:
                h[getGaussKernel - 2, getGaussKernel - 1] = -0.5
                h[getGaussKernel - width, getGaussKernel - 1] = -0.5
                h[getGaussKernel - width + 1, getGaussKernel - width] = -0.5
                h[getGaussKernel - 2 * width, getGaussKernel - width] = -0.5
            else:
                h[i - 1, i] = -1 / 3
                h[i + 1, i] = -1 / 3
                h[i - width, i] = -1 / 3
        elif i % width == 0:
            h[i - width, i] = -1 / 3
            h[i + width, i] = -1 / 3
            h[i + 1, i] = -1 / 3
        elif (i + 1) % width == 0:
            h[i - width, i] = -1 / 3
            h[i + width, i] = -1 / 3
            h[i - 1, i] = -1 / 3
    return h


def norm2squ(x):
    """Return L2norm^2"""
    return torch.sum(torch.pow(x, exponent=2))


class AutoUnmix:
    def __init__(self, L, P, Q, Z, init_edm=None, height=None, width=None, version='com', seed=30, device=None):
        if seed:
            torch.manual_seed(seed)
        self.reg_layer = None
        self.reg_norm = None
        self.frozen_layer = None
        self.lr_decay = 1.
        self.reg_decay = 1e-5
        self.unfreeze_time = 0.9
        self.input_shape = (L,)
        self.loss_code = self._loss_code(mode='0', decay=1e-5)
        if version == 'com':
            self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
            self.model = AutoEncoder(L, P, device=self.device).to(self.device)
            h = torch.from_numpy(smooth_matrix(height=height, width=width)).float()
            self.s0 = torch.abs(h) > 0.1
            self.s1 = h < -0.1
            self.s2 = torch.eye(height * width)
            self.h = h.cuda()
            self.h.requires_grad = True
            self.s0 = self.s0.cuda()
            self.s1 = self.s1.cuda()
            self.s2 = self.s2.cuda()
            self.unfreeze_time = 0.9
            self.opt = torch.optim.AdamW([{'params': self.model.encoder.parameters(), 'lr': 1e-4},
                                          {'params': self.model.decoder.parameters(), 'lr': 1e-3},
                                          {'params': self.h, 'lr': 1e-1}])
        else:
            raise Exception('Version Error. com/cnn')
        self.L, self.P = L, P
        self.Q, self.Z = Q, Z
        self.Q = torch.full((P, P), 0.8).to(self.device)
        self.loss_func = torch.nn.MSELoss()
        self.optimizer = optim.AdamW(self.model.parameters(), lr=2e-4, weight_decay=1e-4)
        self.new_edm = 0
        self.height = height
        self.width = width
        self.version = version
        self.edm = init_edm
        self._list_layer()

    def _list_layer(self):
        for name, para in self.model.named_parameters():
            print(name, end='/')
        print()

    def _freeze(self):
        if self.frozen_layer is None:
            return
        for name, value in self.model.named_parameters():
            if name in self.frozen_layer:
                value.requires_grad = False

    def _unfreeze(self):
        if self.frozen_layer is None:
            return
        for name, para in self.model.named_parameters():
            if name in self.frozen_layer:
                para.requires_grad = True

    def _regularization_loss(self, layer_name=None, weight_decay=1e-5, p=None):
        if layer_name is None:
            return 0
        r_loss = 0
        for name, param in self.model.named_parameters():
            if name in layer_name:
                norm_num = p[layer_name.index(name)]
                if norm_num == 1 or norm_num == 2:
                    r_loss += weight_decay * torch.norm(param, p=norm_num)
        return r_loss

    def _special_loss(self, code, output):
        if self.version == 'com':
            return 1e-4 * norm2squ(torch.mm(self.h * self.s0, code)) + \
                   5 * (norm2squ(torch.sum(self.h * self.s1, dim=0) + torch.tensor(1).cpu()) +
                        norm2squ(self.h * self.s2 - self.s2))
        else:
            return 0

    @staticmethod
    def _loss_code(decay=1e-3, mode='l1-2'):
        if mode == 'l1-2':
            return lambda code: decay * torch.mean(torch.sum(torch.sqrt(torch.abs(code)), dim=-1))
        if mode == '0':
            return lambda code: 0
        else:
            raise Exception('Mode Error! l1-2/0')

    @staticmethod
    def _loss_function(mode='sad'):
        if mode == 'sad':
            return lambda output, target: \
                torch.mean(torch.acos(torch.sum(output * target, dim=-1) /
                                      (torch.norm(output, dim=-1, p=2) * torch.norm(target, dim=-1, p=2))))
        else:
            raise Exception('Version Error! sad/')

    def fit(self, y, max_iter=1000, verbose=True):
        pix1 = torch.from_numpy(y.T).float().to(self.device)
        epoch = 0

        Z = torch.eye(pix1.shape[0]).to(self.device)

        while epoch < max_iter:
            E, A, Q, output, code = self.model(pix1)
            base_loss = self.loss_func(output * 0.95, pix1)
            c_loss = self.loss_code(code)
            r_loss = self._regularization_loss(layer_name=self.reg_layer, p=self.reg_norm, weight_decay=self.reg_decay)
            s_loss = self._special_loss(code, output * 0.95)
            mlm_model = MLM().to(self.device)
            Y, mlmloss = mlm_model(E, A, Q, Z)
            loss = self.loss_func(output, pix1) + mlmloss + base_loss + c_loss + r_loss + s_loss
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

            epoch += 1
            if verbose and (epoch + 1) % (max_iter // 10) == 0:
                print(f"Epoch [{epoch + 1}/{max_iter}], Loss: {loss.item():.4f}")

        return A, Q, Y


if __name__ == '__main__':
    # Load the input data
    im = np.load('E:/project/unmixing/unmixing/daan-update/samson/Y.npy')
    edm = np.load('E:/project/unmixing/unmixing/daan-update/samson/E.npy')
    model = AutoUnmix(L=156, P=3, Q="random", Z=1, init_edm=edm.T, height=95, width=95)
    abd, updated_Q, Y = model.fit(im.reshape(-1, 156).T, max_iter=1800, verbose=True)
    plt.figure(figsize=(12, 6))
    plt.subplot(1, 3, 1)
    plt.imshow(np.rot90(np.rot90(np.reshape(abd[:, 0].cpu().detach().numpy(), (95, 95)))), cmap='viridis')
    plt.colorbar(fraction=0.05)
    plt.title('Abundance 1')
    plt.axis('off')
    plt.subplot(1, 3, 2)
    plt.imshow(np.rot90(np.rot90(np.reshape(abd[:, 1].cpu().detach().numpy(), (95, 95)))), cmap='viridis')
    plt.colorbar(fraction=0.05)
    plt.title('Abundance 2')
    plt.axis('off')
    plt.subplot(1, 3, 3)
    plt.imshow(np.rot90(np.rot90(np.reshape(abd[:, 2].cpu().detach().numpy(), (95, 95)))), cmap='viridis')
    plt.colorbar(fraction=0.05)
    plt.title('Abundance 3')
    plt.axis('off')
    plt.tight_layout()
    plt.show()
    Q_reshaped = np.reshape(updated_Q.cpu().detach().numpy(), (95, 95, 3))
    Q_normalized = np.clip(Q_reshaped, 0, 1)
    plt.figure(figsize=(6, 6))
    plt.imshow(Q_normalized, cmap='viridis')
    plt.colorbar(fraction=0.05)
    plt.imshow(np.rot90(np.rot90(Q_reshaped)), cmap='viridis')
    plt.title('Interaction distributions')
    plt.axis('off')
    plt.gca().set_xticks([])
    plt.gca().set_yticks([])
    plt.show()
    sio.savemat('abundance_matrix.mat', {'A': abd.cpu().detach().numpy()})
    sio.savemat('updated_Q.mat', {'Q': updated_Q.cpu().detach().numpy()})
